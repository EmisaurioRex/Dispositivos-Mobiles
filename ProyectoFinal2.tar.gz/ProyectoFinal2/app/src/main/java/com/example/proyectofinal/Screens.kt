package com.example.proyectofinal

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClienteScreen(onLogout: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var servicioSel by remember { mutableStateOf("") }
    var fechaSel by remember { mutableStateOf("Seleccionar Fecha") }
    var horaSel by remember { mutableStateOf("") }
    var mostrarPerfil by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val GreenPrimary = Color(0xFF00C853)

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.Black,
        unfocusedTextColor = Color.Black,
        focusedLabelColor = GreenPrimary,
        unfocusedLabelColor = Color.Gray,
        cursorColor = GreenPrimary
    )

    if (mostrarPerfil) {
        val usuarioActual = AppRepository.usuarios.find { it.rol == Rol.CLIENTE }
        PerfilScreen(usuario = usuarioActual!!, onBack = { mostrarPerfil = false })
    } else {
        Column(modifier = Modifier.fillMaxSize().background(GreenPrimary)) {
            Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Agendar Cita", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = { mostrarPerfil = true }) { Text("👤", fontSize = 24.sp) }
                TextButton(onClick = onLogout) { Text("Salir", color = Color.White) }
            }

            Surface(modifier = Modifier.fillMaxSize(), shape = RoundedCornerShape(topStart = 35.dp, topEnd = 35.dp), color = Color.White) {
                Column(modifier = Modifier.padding(24.dp).verticalScroll(rememberScrollState())) {
                    Text("Tus datos:", fontWeight = FontWeight.Bold, color = Color.Black)
                    OutlinedTextField(
                        value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp),
                        colors = textFieldColors
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Fecha:", fontWeight = FontWeight.Bold)
                    Button(
                        onClick = {
                            val calendar = java.util.Calendar.getInstance()
                            android.app.DatePickerDialog(context, { _, year, month, day ->
                                fechaSel = "$year-${month + 1}-$day"
                            }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH)).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8F5E9), contentColor = Color.Black)
                    ) { Text("📅 $fechaSel") }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Horario:", fontWeight = FontWeight.Bold)
                    val horas = listOf("09:00", "10:00", "11:00", "12:00", "13:00", "16:00", "17:00", "18:00")
                    FlowRow {
                        horas.forEach { hora ->
                            val ocupado = AppRepository.listaCitas.any { it.fecha == fechaSel && it.hora == hora }
                            FilterChip(
                                selected = (horaSel == hora),
                                onClick = { if(!ocupado) horaSel = hora },
                                label = { Text(hora) },
                                enabled = !ocupado,
                                modifier = Modifier.padding(4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Servicio:", fontWeight = FontWeight.Bold)
                    AppRepository.servicios.forEach { s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = (s == servicioSel), onClick = { servicioSel = s })
                            Text(s, color = Color.Black)
                        }
                    }

                    Button(
                        onClick = {
                            if (nombre.isNotBlank() && servicioSel.isNotBlank() && horaSel.isNotBlank()) {
                                AppRepository.listaCitas.add(Cita(clienteNombre = nombre, servicio = servicioSel, fecha = fechaSel, hora = horaSel, prestadorAsignado = "Staff"))
                                Toast.makeText(context, "Cita agendada", Toast.LENGTH_SHORT).show()
                                onLogout()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 20.dp).height(55.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
                    ) { Text("Confirmar Cita", color = Color.White) }


                    Spacer(modifier = Modifier.height(32.dp))
                    Text("Mis Citas Actuales:", fontWeight = FontWeight.Bold, color = Color.Black)

                    val misCitas = AppRepository.listaCitas.filter { it.clienteNombre.equals(nombre, ignoreCase = true) && nombre.isNotBlank() }

                    if (misCitas.isEmpty() && nombre.isNotBlank()) {
                        Text("No tienes citas registradas con este nombre.", color = Color.Gray, fontSize = 12.sp)
                    }

                    misCitas.forEach { cita ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9))
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cita.servicio, fontWeight = FontWeight.Bold)
                                    Text("${cita.fecha} | ${cita.hora}", fontSize = 12.sp)
                                }
                                IconButton(onClick = {
                                    AppRepository.listaCitas.remove(cita)
                                    Toast.makeText(context, "Cita cancelada", Toast.LENGTH_SHORT).show()
                                }) {
                                    Text("❌", fontSize = 18.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminScreen(onLogout: () -> Unit) {
    var tabIndex by remember { mutableStateOf(0) }
    val tabs = listOf("Servicios", "Sucursales", "Promociones", "Empleados")
    val GreenPrimary = Color(0xFF00C853)

    Column(modifier = Modifier.fillMaxSize().background(GreenPrimary)) {
        Header(title = "Administración", onLogout = onLogout)
        ScrollableTabRow(selectedTabIndex = tabIndex, containerColor = GreenPrimary, contentColor = Color.White, edgePadding = 16.dp) {
            tabs.forEachIndexed { index, title ->
                Tab(selected = tabIndex == index, onClick = { tabIndex = index }, text = { Text(title) })
            }
        }
        Surface(modifier = Modifier.fillMaxSize(), shape = RoundedCornerShape(topStart = 35.dp, topEnd = 35.dp), color = Color.White) {
            when (tabIndex) {
                0 -> GestionLista(titulo = "Servicio", lista = AppRepository.servicios)
                1 -> GestionLista(titulo = "Sucursal", lista = AppRepository.sucursales)
                2 -> GestionLista(titulo = "Promoción", lista = AppRepository.promociones)
                3 -> GestionEmpleados()
            }
        }
    }
}

@Composable
fun GestionEmpleados() {
    var correo by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val context = LocalContext.current
    val GreenPrimary = Color(0xFF00C853)
    val fieldColors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.Black, unfocusedTextColor = Color.Black)

    Column(modifier = Modifier.padding(24.dp).verticalScroll(rememberScrollState())) {
        Text("Registrar Nuevo Empleado", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth(), colors = fieldColors)
        OutlinedTextField(value = correo, onValueChange = { correo = it }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth(), colors = fieldColors)
        OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("Contraseña") }, modifier = Modifier.fillMaxWidth(), colors = fieldColors)
        Button(
            onClick = {
                if(correo.isNotBlank() && nombre.isNotBlank()){
                    AppRepository.usuarios.add(Usuario(correo, pass, nombre, Rol.PRESTADOR))
                    Toast.makeText(context, "Empleado registrado", Toast.LENGTH_SHORT).show()
                    correo = ""; nombre = ""; pass = ""
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp), colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
        ) { Text("Dar de Alta") }

        Spacer(modifier = Modifier.height(20.dp))
        Text("Lista de Empleados:", fontWeight = FontWeight.Bold)
        AppRepository.usuarios.filter { it.rol == Rol.PRESTADOR }.forEach { emp ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9))) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(emp.nombre, fontWeight = FontWeight.Bold, color = Color.Black)
                    Text(emp.correo, color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun GestionLista(titulo: String, lista: MutableList<String>) {
    var nuevoItem by remember { mutableStateOf("") }
    val itemsActualizados = remember { mutableStateListOf<String>().apply { addAll(lista) } }

    Column(modifier = Modifier.padding(24.dp)) {
        OutlinedTextField(value = nuevoItem, onValueChange = { nuevoItem = it }, label = { Text("Nuevo $titulo") }, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.Black, unfocusedTextColor = Color.Black))
        Button(onClick = { if(nuevoItem.isNotBlank()){ lista.add(nuevoItem); itemsActualizados.add(nuevoItem); nuevoItem = "" } }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853))) { Text("Agregar") }
        LazyColumn(modifier = Modifier.padding(top = 16.dp)) {
            items(itemsActualizados) { item ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))) {
                    Text("• $item", modifier = Modifier.padding(16.dp), color = Color.Black)
                }
            }
        }
    }
}

@Composable
fun PerfilScreen(usuario: Usuario, onBack: () -> Unit) {
    var nuevaPass by remember { mutableStateOf("") }
    val GreenPrimary = Color(0xFF00C853)
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().background(GreenPrimary)) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("< Volver", color = Color.White) }
            Text("Mi Perfil", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Surface(modifier = Modifier.fillMaxSize(), shape = RoundedCornerShape(topStart = 35.dp), color = Color.White) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("👤", fontSize = 80.sp)
                Text(usuario.nombre, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(32.dp))
                OutlinedTextField(
                    value = nuevaPass, onValueChange = { nuevaPass = it }, label = { Text("Nueva Contraseña") },
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.Black, unfocusedTextColor = Color.Black)
                )
                Button(onClick = { if(nuevaPass.isNotEmpty()){ usuario.contrasenia = nuevaPass; Toast.makeText(context, "Cambio exitoso", Toast.LENGTH_SHORT).show(); onBack() } },
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp), colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
                ) { Text("Guardar Cambios") }
            }
        }
    }
}


@Composable
fun PrestadorScreen(onLogout: () -> Unit) {
    val GreenPrimary = Color(0xFF00C853)
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().background(GreenPrimary)) {
        Header(title = "Agenda de Citas", onLogout = onLogout)
        Surface(modifier = Modifier.fillMaxSize(), shape = RoundedCornerShape(topStart = 35.dp, topEnd = 35.dp), color = Color.White) {
            LazyColumn(modifier = Modifier.padding(24.dp)) {
                if(AppRepository.listaCitas.isEmpty()) {
                    item { Text("No hay citas agendadas", color = Color.Gray) }
                }
                items(AppRepository.listaCitas) { cita ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9))
                    ) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(cita.clienteNombre, fontWeight = FontWeight.Bold, color = GreenPrimary)
                                Text("Servicio: ${cita.servicio}", color = Color.Black)
                                Text("Fecha: ${cita.fecha} | Hora: ${cita.hora}", color = Color.DarkGray)
                            }

                            IconButton(onClick = {
                                AppRepository.listaCitas.remove(cita)
                                Toast.makeText(context, "Cita eliminada de la agenda", Toast.LENGTH_SHORT).show()
                            }) {
                                Text("🗑️", fontSize = 20.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Header(title: String, onLogout: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.weight(1f))
        TextButton(onClick = onLogout) { Text("Salir", color = Color.White, fontWeight = FontWeight.Bold) }
    }
}