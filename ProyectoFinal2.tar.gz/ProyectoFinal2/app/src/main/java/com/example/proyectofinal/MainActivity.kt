package com.example.proyectofinal

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.proyectofinal.ui.theme.ProyectoFinalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectoFinalTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LoginScreen()
                }
            }
        }
    }
}

@Composable
fun LoginScreen() {
    var correo by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var rolLogueado by remember { mutableStateOf<Rol?>(null) }
    var pantallaActual by remember { mutableStateOf("LOGIN") }

    val context = LocalContext.current
    val GreenPrimary = Color(0xFF00C853)

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.Black,
        unfocusedTextColor = Color.Black,
        focusedLabelColor = GreenPrimary,
        unfocusedLabelColor = Color.Gray,
        cursorColor = GreenPrimary
    )

    when (pantallaActual) {
        "REGISTRO" -> RegistroScreen(onBack = { pantallaActual = "LOGIN" })
        "RECUPERAR" -> RecuperarPasswordScreen(onBack = { pantallaActual = "LOGIN" })
        "LOGIN" -> {
            if (rolLogueado == null) {
                Column(
                    modifier = Modifier.fillMaxSize().background(Color(0xFFF1F8E9)).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(modifier = Modifier.size(100.dp), shape = CircleShape, color = GreenPrimary) {
                        Box(contentAlignment = Alignment.Center) { Text("✂️", fontSize = 40.sp) }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Bienvenido", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    Spacer(modifier = Modifier.height(32.dp))

                    OutlinedTextField(
                        value = correo, onValueChange = { correo = it }, label = { Text("Correo") },
                        shape = RoundedCornerShape(30.dp), modifier = Modifier.fillMaxWidth(),
                        colors = textFieldColors
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = password, onValueChange = { password = it }, label = { Text("Contraseña") },
                        visualTransformation = PasswordVisualTransformation(),
                        shape = RoundedCornerShape(30.dp), modifier = Modifier.fillMaxWidth(),
                        colors = textFieldColors
                    )

                    TextButton(
                        onClick = { pantallaActual = "RECUPERAR" },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Olvidé mi contraseña", color = GreenPrimary)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val usuario = AppRepository.usuarios.find { it.correo == correo && it.contrasenia == password }
                            if (usuario != null) {
                                rolLogueado = usuario.rol
                            } else {
                                Toast.makeText(context, "Datos incorrectos", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(55.dp),
                        shape = RoundedCornerShape(30.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
                    ) { Text("Ingresar", fontWeight = FontWeight.Bold, color = Color.White) }

                    TextButton(onClick = { pantallaActual = "REGISTRO" }) {
                        Text("¿No tienes cuenta? Regístrate aquí", color = GreenPrimary)
                    }
                }
            } else {

                when (rolLogueado) {
                    Rol.ADMINISTRADOR -> AdminScreen(onLogout = { rolLogueado = null })
                    Rol.PRESTADOR -> PrestadorScreen(onLogout = { rolLogueado = null })
                    Rol.CLIENTE -> ClienteScreen(onLogout = { rolLogueado = null })
                    null -> { rolLogueado = null } 
                }
            }
        }
    }
}

@Composable
fun RegistroScreen(onBack: () -> Unit) {
    var c by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var n by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().padding(24.dp).background(Color.White), verticalArrangement = Arrangement.Center) {
        Text("Crear Cuenta", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00C853))
        Spacer(modifier = Modifier.height(20.dp))
        OutlinedTextField(value = n, onValueChange = { n = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = c, onValueChange = { c = it }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = p, onValueChange = { p = it }, label = { Text("Contraseña") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                if(c.contains("@")) {
                    AppRepository.usuarios.add(Usuario(c, p, n, Rol.CLIENTE))
                    Toast.makeText(context, "Registro exitoso", Toast.LENGTH_SHORT).show()
                    onBack()
                } else {
                    Toast.makeText(context, "Correo inválido", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853))
        ) { Text("Registrar", color = Color.White) }
        TextButton(onClick = onBack) { Text("Volver") }
    }
}

@Composable
fun RecuperarPasswordScreen(onBack: () -> Unit) {
    var mail by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().padding(24.dp).background(Color.White), verticalArrangement = Arrangement.Center) {
        Text("Nueva Contraseña", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00C853))
        Spacer(modifier = Modifier.height(20.dp))
        OutlinedTextField(value = mail, onValueChange = { mail = it }, label = { Text("Tu correo") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = newPass, onValueChange = { newPass = it }, label = { Text("Nueva clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                val user = AppRepository.usuarios.find { it.correo == mail }
                if (user != null) {
                    user.contrasenia = newPass
                    Toast.makeText(context, "Actualizada con éxito", Toast.LENGTH_SHORT).show()
                    onBack()
                } else {
                    Toast.makeText(context, "No existe el usuario", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853))
        ) { Text("Guardar", color = Color.White) }
        TextButton(onClick = onBack) { Text("Cancelar") }
    }
}