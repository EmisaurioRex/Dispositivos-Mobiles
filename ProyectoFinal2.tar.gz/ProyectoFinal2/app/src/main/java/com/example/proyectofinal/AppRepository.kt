package com.example.proyectofinal

import androidx.compose.runtime.mutableStateListOf
import java.util.UUID


enum class Rol { ADMINISTRADOR, PRESTADOR, CLIENTE }


data class Usuario(
    val correo: String,
    var contrasenia: String,
    val nombre: String,
    val rol: Rol
)

data class Cita(
    val id: String = UUID.randomUUID().toString(),
    val clienteNombre: String,
    val servicio: String,
    val fecha: String,
    val hora: String,
    val prestadorAsignado: String
)

object AppRepository {

    val usuarios = mutableListOf(
        Usuario("admin@test.com", "123", "Administrador", Rol.ADMINISTRADOR),
        Usuario("empleado@test.com", "123", "Juan Estilista", Rol.PRESTADOR),
        Usuario("cliente@test.com", "123", "Cliente Test", Rol.CLIENTE)
    )


    val servicios = mutableListOf("Corte de Cabello", "Manicura", "Barba")
    val sucursales = mutableListOf("Sucursal Norte", "Sucursal Centro")
    val promociones = mutableListOf("Descuento Buen Fin", "2x1 Lunes")

    val listaCitas = mutableStateListOf<Cita>()
}